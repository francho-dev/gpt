var _0x7ba1=["\x69\x6E\x70\x75\x74\x51\x75\x65\x73\x74\x69\x6F\x6E","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64","\x72\x65\x73\x75\x6C\x74","\x6B\x65\x79\x70\x72\x65\x73\x73","\x76\x61\x6C\x75\x65","\x6B\x65\x79","\x45\x6E\x74\x65\x72","\x61\x74\x72\x61\x73","\x41\x74\x72\x61\x73","\x61\x64\x64\x45\x76\x65\x6E\x74\x4C\x69\x73\x74\x65\x6E\x65\x72","\x73\x6B\x2D\x39\x45\x6F\x36\x4D\x6F\x38\x38\x31\x6D\x67\x39\x6B\x4F\x58\x62\x6A\x59\x4A\x65\x54\x33\x42\x6C\x62\x6B\x46\x4A\x79\x45\x63\x61\x64\x69\x5A\x4C\x68\x75\x54\x66\x79\x6A\x71\x66\x4B\x6E\x37\x6E"];const inputQuestion=document[_0x7ba1[1]](_0x7ba1[0]);const result=document[_0x7ba1[1]](_0x7ba1[2]);inputQuestion[_0x7ba1[9]](_0x7ba1[3],(_0xe640x3)=>{if(inputQuestion[_0x7ba1[4]]&& _0xe640x3[_0x7ba1[5]]=== _0x7ba1[6]){if(inputQuestion[_0x7ba1[4]]=== _0x7ba1[7]|| inputQuestion[_0x7ba1[4]]=== _0x7ba1[8]){salir_davinci()}else {SendQuestion()}}});const w=_0x7ba1[10]

  function SendQuestion() {

var _0x8232=["\x76\x61\x6C\x75\x65"];var sQuestion=inputQuestion[_0x8232[0]]

    fetch("https://api.openai.com/v1/completions", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: "Bearer " + w,
        },
        body: JSON.stringify({
          model: "text-davinci-003",
          prompt: sQuestion,
          max_tokens: 2048,
          temperature: 0.5,
        }),
      })
      .then((response) => response.json())
      .then((json) => {
        if (result.value) result.value += "\n";

        if (json.error?.message) {
          result.value += `Error: ${json.error.message}`;
        } else if (json.choices?.[0].text) {
          var text = json.choices[0].text;

          result.value += "GPT ilegal: " + text;
        }

        result.scrollTop = result.scrollHeight;
      })
      .catch((error) => console.error("Error:", error))
      .finally(() => {
        inputQuestion.value = "";
        inputQuestion.disabled = false;
        inputQuestion.focus();
      });

var _0x63ce=["\x76\x61\x6C\x75\x65","\x0A\x0A\x0A","\x74\x75\x3A\x20","","\x65\x73\x70\x65\x72\x61\x20\x6D\x61\x73\x74\x65\x72\x2E\x2E\x2E","\x64\x69\x73\x61\x62\x6C\x65\x64","\x73\x63\x72\x6F\x6C\x6C\x54\x6F\x70","\x73\x63\x72\x6F\x6C\x6C\x48\x65\x69\x67\x68\x74"];if(result[_0x63ce[0]]){result[_0x63ce[0]]+= _0x63ce[1]};result[_0x63ce[0]]+= `${_0x63ce[2]}${sQuestion}${_0x63ce[3]}`;inputQuestion[_0x63ce[0]]= _0x63ce[4];inputQuestion[_0x63ce[5]]= true;result[_0x63ce[6]]= result[_0x63ce[7]]

  }
  
var _0x8164=["\x76\x61\x6C\x75\x65","","\x64\x69\x73\x70\x6C\x61\x79","\x73\x74\x79\x6C\x65","\x66\x6C\x65\x78","\x6E\x6F\x6E\x65"];function salir_davinci(){inputQuestion[_0x8164[0]]= _0x8164[1];elegir_ai[_0x8164[3]][_0x8164[2]]= _0x8164[4];div_chat_gpt_text_davinci[_0x8164[3]][_0x8164[2]]= _0x8164[5]}