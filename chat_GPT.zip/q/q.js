
var _0x9b3b=["\x65\x6C\x65\x67\x69\x72\x5F\x61\x69","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64","\x70\x72\x65\x67\x75\x6E\x74\x61","\x72\x65\x73\x70\x75\x65\x73\x74\x61\x5F\x63\x68\x61\x74\x67\x70\x74","\x47\x50\x54\x20\x33","\x65\x73\x70\x65\x72\x61\x20\x6D\x61\x73\x74\x65\x72\x20\x2E\x2E\x2E","\x6B\x65\x79\x70\x72\x65\x73\x73","\x76\x61\x6C\x75\x65","\x6B\x65\x79","\x45\x6E\x74\x65\x72","\x61\x74\x72\x61\x73","\x41\x74\x72\x61\x73","\x61\x64\x64\x45\x76\x65\x6E\x74\x4C\x69\x73\x74\x65\x6E\x65\x72","\x73\x6B\x2D\x39\x45\x6F\x36\x4D\x6F\x38\x38\x31\x6D\x67\x39\x6B\x4F\x58\x62\x6A\x59\x4A\x65\x54\x33\x42\x6C\x62\x6B\x46\x4A\x79\x45\x63\x61\x64\x69\x5A\x4C\x68\x75\x54\x66\x79\x6A\x71\x66\x4B\x6E\x37\x6E"];const elegir_ai=document[_0x9b3b[1]](_0x9b3b[0]);const barra_pregunta=document[_0x9b3b[1]](_0x9b3b[2]);const resultado_chatgpt=document[_0x9b3b[1]](_0x9b3b[3]);const name_ai=_0x9b3b[4];const text_carga=_0x9b3b[5];barra_pregunta[_0x9b3b[12]](_0x9b3b[6],(_0xb246x6)=>{if(barra_pregunta[_0x9b3b[7]]&& _0xb246x6[_0x9b3b[8]]=== _0x9b3b[9]){if(barra_pregunta[_0x9b3b[7]]=== _0x9b3b[10]|| barra_pregunta[_0x9b3b[7]]=== _0x9b3b[11]){salir_turbo()}else {peticion()}}});const key=_0x9b3b[13]

var _0xb11d=["\x68\x74\x74\x70\x73\x3A\x2F\x2F\x61\x70\x69\x2E\x6F\x70\x65\x6E\x61\x69\x2E\x63\x6F\x6D\x2F\x76\x31\x2F\x63\x68\x61\x74\x2F\x63\x6F\x6D\x70\x6C\x65\x74\x69\x6F\x6E\x73"];let url=_0xb11d[0];let pregunta

function peticion (){
 
var _0xfe71=["\x76\x61\x6C\x75\x65"];let con=acceso();pregunta= barra_pregunta[_0xfe71[0]]

   const respuesta = fetch (url, {
      
      method: "POST",
      
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + key,
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        "messages": [{"role": "user", "content": pregunta}],
       max_tokens: 2048,
       temperature: 0.5,
      }),
    })
    .then((response) => response.json())
    .then((json) => {
    
  var _0x9927=[];let datos=json

     if (resultado_chatgpt.value) resultado_chatgpt.value += "\n";

      if (json.error?.message) {
        
        result.value += `Error: ${json.error.message}`;
        
      } else if (datos.choices[0].message.content != null) {
   
 let res_gpt = datos.choices[0].message.content;
 

resultado_chatgpt.value += name_ai + ": " + res_gpt;

     }
    
      resultado_chatgpt.scrollTop = resultado_chatgpt.scrollHeight;
      
    })
    .catch((error) => console.error("Error:", error))
    .finally(() => {
      barra_pregunta.value = "";
      barra_pregunta.disabled = false;
    });

var _0x7929=["\x76\x61\x6C\x75\x65","\x0A\x0A\x0A","\x74\x75\x3A\x20","","\x64\x69\x73\x61\x62\x6C\x65\x64","\x73\x63\x72\x6F\x6C\x6C\x54\x6F\x70","\x73\x63\x72\x6F\x6C\x6C\x48\x65\x69\x67\x68\x74"];if(resultado_chatgpt[_0x7929[0]]){resultado_chatgpt[_0x7929[0]]+= _0x7929[1]};resultado_chatgpt[_0x7929[0]]+= `${_0x7929[2]}${pregunta}${_0x7929[3]}`;barra_pregunta[_0x7929[0]]= text_carga;barra_pregunta[_0x7929[4]]= true;resultado_chatgpt[_0x7929[5]]= resultado_chatgpt[_0x7929[6]]
}

var _0x9a2d=["\x68\x6F\x6C\x61","\x63\x68\x61\x75","\x73\x65\x78\x6F","\x6C\x65\x6E\x67\x74\x68","\x76\x61\x6C\x75\x65"];function acceso(){let _0xffc7x2=0;let _0xffc7x3=[_0x9a2d[0],_0x9a2d[1],_0x9a2d[2]];for(let _0xffc7x4=0;_0xffc7x4< _0xffc7x3[_0x9a2d[3]];_0xffc7x4++){if(barra_pregunta[_0x9a2d[4]]== _0xffc7x3[_0xffc7x4]){return false;_0xffc7x2= 1};if(_0xffc7x4== _0xffc7x3[_0x9a2d[3]]){if(_0xffc7x2== 0){return true}}}}

var _0xd661=["\x76\x61\x6C\x75\x65","","\x64\x69\x73\x70\x6C\x61\x79","\x73\x74\x79\x6C\x65","\x6E\x6F\x6E\x65","\x66\x6C\x65\x78"];function salir_turbo(){barra_pregunta[_0xd661[0]]= _0xd661[1];div_chat_gpt_turbo[_0xd661[3]][_0xd661[2]]= _0xd661[4];elegir_ai[_0xd661[3]][_0xd661[2]]= _0xd661[5]}